#pragma once

namespace torch::utils {

void initializeLayouts();

}

#pragma once

namespace torch::jit {
static const char* valid_single_char_tokens = "+-*/%@()[]:,={}><.?!&^|~";
} // namespace torch::jit

#pragma once

#include <torch/csrc/inductor/aoti_torch/generated/c_shim_cpu.h>

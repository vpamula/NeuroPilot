#include <torch/csrc/python_headers.h>

namespace torch::inductor {

void initAOTIPackageBindings(PyObject* module);

} // namespace torch::inductor

#pragma once

#include <torch/csrc/inductor/aoti_include/common.h>
#include <torch/csrc/inductor/aoti_runtime/arrayref_tensor.h>
#include <torch/csrc/inductor/aoti_runtime/thread_local.h>
#include <torch/csrc/inductor/array_ref_impl.h>
#include <torch/csrc/inductor/cpp_wrapper/device_internal/cpu.h>

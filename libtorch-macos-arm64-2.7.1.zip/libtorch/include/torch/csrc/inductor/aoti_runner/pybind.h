#include <torch/csrc/python_headers.h>

namespace torch::inductor {

void initAOTIRunnerBindings(PyObject* module);

} // namespace torch::inductor
